
Name: Mahnaz Rafia Islam
Reg. No.: 17101007
Section: A


3)
a. Yes, I did collaborate with Israt Jahan Jenny on mouse based camera rotation.
   

b. Yes, i have taken helps from few websites to clear out my concept regarding the functions.
	Links are provided below.
	glLight- https://www.khronos.org/registry/OpenGL-Refpages/gl2.1/xhtml/glLight.xml
	glRotate- https://community.khronos.org/t/glrotatef/14062
	glMaterialfv- https://docs.microsoft.com/en-us/windows/win32/opengl/glmaterialfv#:~:text=The%20glMaterialfv%20function%20assigns%20values,%2Dsided%20lighting%20is%20enabled).
	camera zoom in and out using mouse- https://community.khronos.org/t/zoom-in-zoom-out-pan-using-mouse/71464

c. Yes. There is an existing problem in my code which is I cannot move the light source at the back of the object.

d. No. I haven't done any extra work.

e. The assignment was not so long or hard from my perspective as I have successfully completed all the features related to it.
   It was really fun to work with OpenGL and explore how computer graphics works. I have leaned so much from this assignment. 